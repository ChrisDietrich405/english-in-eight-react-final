import { Link } from "react-router-dom"

export default function PastTenseVerbDefinition() {
    return(
        <>
        <div className="page-title">
            <h2>Past Tense Verbs</h2>
        </div>
        <div className="page-body">
            <p className="grammar-explanation-paragraph">There are four past tenses in English. The past tense refers to events that have happened in the past. The simple past refers to events that have started and ended in the past. The past continuous refers to an event that was in progress at some point in the past. The past perfect tense is used to make it clear that one event happened before another in the past. The past perfect continuous tense shows that an action that started in the past continued up until another time in the past. 
            </p>
            <div className="btn-container btn-flex">
                <Link to="/past-verb-tenses/past-simple" className=" btn btn-primary">Simple Past</Link>
                <Link to="/past-verb-tenses/past-continuous" className="btn btn-primary">Past Continuous</Link>
                <Link to="/past-verb-tenses/past-perfect" className="btn btn-primary">Past Perfect</Link>
                <Link to="/past-verb-tenses/past-perfect-continuous" className="btn btn-primary">Past Perfect Continuous</Link>
            </div>
            
        </div>
        </>
    )
}